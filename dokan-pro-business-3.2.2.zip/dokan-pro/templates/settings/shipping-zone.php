<div class="dokan-shipping-wrap">

</div>